@extends('layouts.master')

@section('title')
    Dashboard
@endsection

@section('content')
	
@endsection